<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Online Event Management</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="assets/build/css/app-638f2af77c.css">
        <link rel="preload" href="assets/fonts/proximanova/regular/proximanova-regular-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/regular/proximanova-regular-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/bold/proximanova-bold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/bold/proximanova-bold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/light/proximanova-light-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/light/proximanova-light-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff2" as="font" type="font/woff2" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/thin/Proxima-Nova-Thin.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/thin/Proxima-Nova-Thin.ttf" as="font" type="font/ttf" crossorigin />
        <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        //include auth.php file on all secure pages
        include("auth.php");
        ?>
        <nav class="navbar navbar-default fixed-top navbar-expand-lg navbar-dark bg-dark pad20 scrolled" data-spy="affix" data-offset-top="400">
            <div class="container">
                <a class="navbar-brand logo-fntsz1pt5" href="index.php">QIS EVENTS</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Events
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item active" href="wedding.php">Wedding Events</a>
                                <a class="dropdown-item" href="party.php">Party Events</a>
                                <a class="dropdown-item" href="corporate.php">Corporate Events</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact us</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--/ End of navbar /-->
        <section class="section-event-main-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="abt-title mrgntop100">
                            <h2 class="text-center text-white">Wedding Events</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of about title /-->
        <section class="section-main-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="wed-title mrgnbtm35">
                            <h3>Wedding Planners in Ongole</h3>
                            <h6 class="text-justify lineht25">Wedding is the beginning of the family and it is a lifelong commitment and who wish to spend entire life being partners with each other. It is the celebration of an event once in a lifetime and is very important that every person must be a part of this joyous occasion from the bride and grooms families.</h6>
                            <h6 class="text-justify lineht25">QIS Events Wedding Planners In Ongole keeps inventing the new ways and ideas for providing unique experiences to all the clients giving foremost importance their inputs and desires.</h6>
                        </div>
                        <div class="list-title">
                            <h3>QIS Events Wedding Services includes:</h3>
                            <ul class="lsttycrcl">
                                <li>Fully Dedicated and Execution Team</li>
                                <li>Preferred Vendors Partners</li>
                                <li>Diagramming, sketching, blueprints and mockups</li>
                                <li>Personal Design Presentations</li>
                                <li>Styling and Theme</li>
                                <li>Event Entertainment</li>
                                <li>Personalized to do list</li>
                                <li>Pre-Qualified Vendor recommendations</li>
                                <li>Guest Services like transportation, welcome boxes, room blocks and Management</li>
                            </ul>
                        </div>
                        <div class="wed-img">
                            <img src="assets/images/wedding.png" class="img-fluid" alt="img">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of main content /-->
        <section class="contact-foo-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="contact">
                                    <h3 class="text-white">Contact</h3>
                                    <p class="footer_color_white text-white">
                                        QIS COLLEGE OF ENGINEERING & TECHNOLOGY<br> vengamukkapalem, Ongole - 523272<br> Andhra Pradesh, India<br>
                                        <span class="footer_color_white">E:</span> <a class="footer_color_white text-white" href="mailto:principal@qiscet.edu.in">principal@qiscet.edu.in</a><br>
                                        <span class="footer_color_white">T:</span> <a class="footer_color_white text-white" href="tel:+91 8592 - 281023">+91 8592 - 281023</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4"></div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <aside class="f_widget f_subs_widget">
                                    <div class="f_title" style="padding-bottom: 25px !important;">
                                        <h3 class="text-white">Follow us</h3>
                                    </div>
                                    <div class="input-group">
                                        <a target="_blank" href="#"><i class="fab fa-google-plus-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-linkedin" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-facebook-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-twitter-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                    </div>
                                </aside>
                            </div>
                        </div>
                        <p class="text-white text-center mrgntop-50">Copyright © 2019 QIS Group of Institutions - All right reserved.</p>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of contact us /-->
        <script src="assets/js/jquery-3.4.1.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $(window).scroll(function () {
                    $("nav").toggleClass("scrolled", $(this).scrollTop() > 50);
                });
            });
        </script>
    </body>
</html>
