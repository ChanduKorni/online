<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Online Event Management</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="assets/build/css/app-638f2af77c.css">
        <link rel="preload" href="assets/fonts/proximanova/regular/proximanova-regular-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/regular/proximanova-regular-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/bold/proximanova-bold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/bold/proximanova-bold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/light/proximanova-light-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/light/proximanova-light-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff2" as="font" type="font/woff2" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/thin/Proxima-Nova-Thin.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/thin/Proxima-Nova-Thin.ttf" as="font" type="font/ttf" crossorigin />
        <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        //include auth.php file on all secure pages
        include("auth.php");
        ?>
        <nav class="navbar navbar-default fixed-top navbar-expand-lg navbar-dark bg-dark pad20 scrolled" data-spy="affix" data-offset-top="400">
            <div class="container">
                <a class="navbar-brand logo-fntsz1pt5" href="index.php">QIS EVENTS</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Events
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="wedding.php">Wedding Events</a>
                                <a class="dropdown-item" href="party.php">Party Events</a>
                                <a class="dropdown-item" href="corporate.php">Corporate Events</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="customers/login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact us</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--/ End of navbar /-->
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/images/banner1.jpg" class="d-block w-100" alt="img">
                </div>
                <div class="carousel-item">
                    <img src="assets/images/banner3.jpg" class="d-block w-100" alt="img">
                </div>
                <div class="carousel-item">
                    <img src="assets/images/banner4.jpg" class="d-block w-100" alt="img">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <!--/End of carousel /-->
        <section class="section-main-padding bg-black">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="abt-title text-center">
                            <h2 class="text-white">Welcome To QIS Events</h2>
                            <h6 class="text-white">We Imagine What You Desire & We Create What You Need</h6>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of about /-->
        <section class="section-main-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="row mrgnbtm35">
                            <div class="col-sm-4 col-md-4 col-lg-4 mob-mrgnbtm30">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <img src="assets/images/wed.png" class="img-fluid mrgnbtm10" alt=""/>
                                        <h3 class="fntsz1pt5 clr-blk">Wedding Events</h3>
                                        <h6 class="lineht25 text-justify mrgnbtm35">QIS Events Believe In Planning Wedding Event To Be A Joyous And Pleasant Experience With Detailed Planning Process And Stress-Free Methods.</h6>
                                        <a class="button-work" href="#">Know more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4 mob-mrgnbtm30">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <img src="assets/images/nparty.png" class="img-fluid mrgnbtm10" alt=""/>
                                        <h3 class="fntsz1pt5 clr-blk">Party Events</h3>
                                        <h6 class="lineht25 text-justify mrgnbtm35">You Are At The Right Place To Have Unforgettable Moments With Friends, Family And Co Workers Including Great Foods And Drinks.</h6>
                                        <a class="button-work" href="#">Know more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <img src="assets/images/corporaten.png" class="img-fluid mrgnbtm10" alt=""/>
                                        <h3 class="fntsz1pt5 clr-blk">Corporate Events</h3>
                                        <h6 class="lineht25 text-justify mrgnbtm60">We Customize Outstanding Support and Customized Event to Fit Your Group Size, Outcomes And Goals In Allotted Time.</h6>
                                        <a class="button-work" href="#">Know more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-lg-4 mob-mrgnbtm30">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <img src="assets/images/ndesign.png" class="img-fluid mrgnbtm10" alt=""/>
                                        <h3 class="fntsz1pt5 clr-blk">Design & Decor</h3>
                                        <h6 class="lineht25 text-justify mrgnbtm60">QIS Events Believes In Imagining Themes That Are Specifically To Your Thoughts To Add A New Spark To The Event.</h6>
                                        <a class="button-work" href="#">Know more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4 mob-mrgnbtm30">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <img src="assets/images/nphoto.png" class="img-fluid mrgnbtm10" alt=""/>
                                        <h3 class="fntsz1pt5 clr-blk">Photography</h3>
                                        <h6 class="lineht25 text-justify mrgnbtm35">QIS Events Main Goal Is To Capture The Present Energy Moment Of Event, Guests Interactions And Running Activities To Make A Cherish Moment Forever.</h6>
                                        <a class="button-work" href="#">Know more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <img src="assets/images/ncatering.png" class="img-fluid mrgnbtm10" alt=""/>
                                        <h3 class="fntsz1pt5 clr-blk">Catering</h3>
                                        <h6 class="lineht25 text-justify mrgnbtm35">QIS Events Catering Services is ready to satisfy you with most discerning, delicious, local sustainable and health conscious plates.</h6>
                                        <a class="button-work" href="#">Know more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of events cards /-->
        <section class="section-main-padding bg-cream">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <nav class="mrgnbtm35">
                            <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <a class="nav-item nav-link active" id="nav-learning-tab" data-toggle="tab" href="#nav-learning" role="tab" aria-controls="nav-learning" aria-selected="true">Learning</a>
                                <a class="nav-item nav-link" id="nav-planning-tab" data-toggle="tab" href="#nav-planning" role="tab" aria-controls="nav-planning" aria-selected="false">Planning</a>
                                <a class="nav-item nav-link" id="nav-execute-tab" data-toggle="tab" href="#nav-execute" role="tab" aria-controls="nav-execute" aria-selected="false">Execute</a>
                                <a class="nav-item nav-link" id="nav-celebrate-tab" data-toggle="tab" href="#nav-celebrate" role="tab" aria-controls="nav-celebrate" aria-selected="false">Celebrate</a>
                            </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-learning" role="tabpanel" aria-labelledby="nav-learning-tab">
                                <div class="row">
                                    <div class="col-sm-2 col-md-2 col-lg-2">
                                        <div class="img">
                                            <img src="assets/images/instruction.png" class="img-fluid" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <div class="tab-title">
                                            <h3 class="fntsz1pt5">At QIS Events we firmly believe in creating successful events.</h3>
                                            <h6 class="lineht25 text-justify">At QIS Events we firmly believe successful event creation is not all about flowers, lightning & fabrics, its way beyond that and our first step to make a celebrating event would be learning. First step towards your event would be understanding you, your event nature, what are areas where you want more importance on, your budget and your tastes.</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="nav-planning" role="tabpanel" aria-labelledby="nav-planning-tab">
                                <div class="row">
                                    <div class="col-sm-2 col-md-2 col-lg-2">
                                        <div class="img">
                                            <img src="assets/images/planning.png" class="img-fluid" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <div class="tab-title">
                                            <h3 class="fntsz1pt5">As said "Goal without plan is just a Wish". We firmly believe this and we plan each and every element, craft carefully to create a flawless events.</h3>
                                            <h6 class="lineht25 text-justify">From set up to clean up how element is carefully planned so that you can sit back and relax with your guests. We ensure everything is taken care. Creating Successful Events through People-Centered, Ethnic Traditional Designs.</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="nav-execute" role="tabpanel" aria-labelledby="nav-execute-tab">
                                <div class="row">
                                    <div class="col-sm-2 col-md-2 col-lg-2">
                                        <div class="img">
                                            <img src="assets/images/execution.png" class="img-fluid" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <div class="tab-title">
                                            <h3 class="fntsz1pt5">As we have taken enough time to learn & Plan your event, goals of your event, It's time for you to sit back and relax.</h3>
                                            <h6 class="lineht25 text-justify">Your events are executed as planned as inline to your goals and objectives of your event. From our network of preferred vendors, industry connections and years of experience, we can deliver a full service event management experience.</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="nav-celebrate" role="tabpanel" aria-labelledby="nav-celebrate-tab">
                                <div class="row">
                                    <div class="col-sm-2 col-md-2 col-lg-2">
                                        <div class="img">
                                            <img src="assets/images/dance.png" class="img-fluid" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-sm-10 col-md-10 col-lg-10">
                                        <div class="tab-title">
                                            <h3 class="fntsz1pt5">Finally, this is where our event management expertise comes into play. At our core, we love events. We love the on site details, We love to see you celebrate the best moment of your life.</h3>
                                            <h6 class="lineht25 text-justify">From meticulous management of facility details to AV, catering and on site coordination, we ensure every detail is looked after. Managing your event using a strategic overall plan and a methodical management approach allows you celebrate with your family, friends & Guests.</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of tabs /-->
        <section class="section-main-padding bg-black">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="ach-title mrgnbtm35">
                            <h2 class="text-center text-white">Achievements</h2>
                        </div>
                        <div class="row">
                            <div class="col-sm-3 col-md-3 col-lg-3">
                                <div class="icon text-center">
                                    <i class="fas fa-suitcase" style="font-size: 36px; color: #FFF; margin-bottom: 10px;"></i>
                                    <h5 class="text-white">650</h5>
                                    <h6 class="text-white">Events</h6>
                                </div>
                            </div>
                            <div class="col-sm-3 col-md-3 col-lg-3">
                                <div class="icon text-center">
                                    <i class="fas fa-users" style="font-size: 36px; color: #FFF; margin-bottom: 10px;"></i>
                                    <h5 class="text-white">530</h5>
                                    <h6 class="text-white">Happy Clients</h6>
                                </div>
                            </div>
                            <div class="col-sm-3 col-md-3 col-lg-3">
                                <div class="icon text-center">
                                    <i class="fas fa-trophy" style="font-size: 36px; color: #FFF; margin-bottom: 10px;"></i>
                                    <h5 class="text-white">83</h5>
                                    <h6 class="text-white">Awards</h6>
                                </div>
                            </div>
                            <div class="col-sm-3 col-md-3 col-lg-3">
                                <div class="icon text-center">
                                    <i class="fas fa-clock" style="font-size: 36px; color: #FFF; margin-bottom: 10px;"></i>
                                    <h5 class="text-white">38000</h5>
                                    <h6 class="text-white">Hours Work</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End of achievements-->
        <section class="section-main-padding bg-cream">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="exp-title text-center">
                            <h2 class="mrgnbtm10">Talk to Us to Experience The Flawless Event</h2>
                            <h6 class="mrgnbtm35">Creating Best Memories & Moments.</h6>
                            <a class="button-work" href="#">Contact us</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End of experience-->
        <section class="contact-foo-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="contact">
                                    <h3 class="text-white">Contact</h3>
                                    <p class="footer_color_white text-white">
                                        QIS COLLEGE OF ENGINEERING & TECHNOLOGY<br> vengamukkapalem, Ongole - 523272<br> Andhra Pradesh, India<br>
                                        <span class="footer_color_white">E:</span> <a class="footer_color_white text-white" href="mailto:principal@qiscet.edu.in">principal@qiscet.edu.in</a><br>
                                        <span class="footer_color_white">T:</span> <a class="footer_color_white text-white" href="tel:+91 8592 - 281023">+91 8592 - 281023</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4"></div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <aside class="f_widget f_subs_widget">
                                    <div class="f_title" style="padding-bottom: 25px !important;">
                                        <h3 class="text-white">Follow us</h3>
                                    </div>
                                    <div class="input-group">
                                        <a target="_blank" href="#"><i class="fab fa-google-plus-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-linkedin" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-facebook-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-twitter-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                    </div>
                                </aside>
                            </div>
                        </div>
                        <p class="text-white text-center mrgntop-50">Copyright © 2019 QIS Group of Institutions - All right reserved.</p>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of contact us /-->
        <script src="assets/js/jquery-3.4.1.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $(window).scroll(function () {
                    $("nav").toggleClass("scrolled", $(this).scrollTop() > 50);
                });
            });
        </script>
    </body>
</html>
