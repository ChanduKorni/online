<!DOCTYPE html>
<html>
    <head>
        <title>Registration</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../assets/build/css/app-638f2af77c.css">
        <link rel="preload" href="../assets/fonts/proximanova/regular/proximanova-regular-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/regular/proximanova-regular-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/bold/proximanova-bold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/bold/proximanova-bold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/light/proximanova-light-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/light/proximanova-light-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/semibold/proximanova-semibold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff2" as="font" type="font/woff2" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/thin/Proxima-Nova-Thin.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/thin/Proxima-Nova-Thin.ttf" as="font" type="font/ttf" crossorigin />
        <link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body class="bg-gradient-primary">
        <?php
        require('../db.php');
// If form submitted, insert values into the database.
        if (isset($_REQUEST['username'])) {
            // removes backslashes
            $username = stripslashes($_REQUEST['username']);
            //escapes special characters in a string
            $username = mysqli_real_escape_string($con, $username);
            $email = stripslashes($_REQUEST['email']);
            $email = mysqli_real_escape_string($con, $email);
            $password = stripslashes($_REQUEST['password']);
            $password = mysqli_real_escape_string($con, $password);
            $query = "INSERT into `customers` (username, password, email)
VALUES ('$username', '" . md5($password) . "', '$email')";
            $result = mysqli_query($con, $query);
            if ($result) {
                echo "<div class='form'>
<h3>You are registered successfully.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
            }
        } else {
            ?>
            <section>
                <div class="container">
                    <div class="card o-hidden border-0 shadow-lg my-5">
                        <div class="card-body p-0">
                            <!-- Nested Row within Card Body -->
                            <div class="row">
                                <div class="col-lg-6 d-none d-lg-block bg-register-image"></div>
                                <div class="col-lg-6">
                                    <div class="p-5">
                                        <div class="text-center">
                                            <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                                        </div>
                                        <form name="registration" action="" method="post">
                                            <div class="form-group row">
                                                <div class="col-sm-6 mb-3 mb-sm-0">
                                                    <input class="form-control form-control-user" type="text" name="username" placeholder="Username" required />
                                                </div>
                                                <div class="col-sm-6">
                                                    <input class="form-control form-control-user" type="password" name="password" placeholder="Password" required />
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control form-control-user" type="email" name="email" placeholder="Email" required />
                                            </div>
                                            <input class="btn btn-primary btn-user btn-block" type="submit" name="submit" value="Register" />
                                            <hr>
                                            <a href="#" class="btn btn-google btn-user btn-block">
                                                <i class="fab fa-google fa-fw"></i> Register with Google
                                            </a>
                                            <a href="#" class="btn btn-facebook btn-user btn-block">
                                                <i class="fab fa-facebook-f fa-fw"></i> Register with Facebook
                                            </a>
                                        </form>
                                        <hr>
                                        <div class="text-center">
                                            <a class="small" href="forgot-password.php">Forgot Password?</a>
                                        </div>
                                        <div class="text-center">
                                            <a class="small" href="login.php">Already have an account? Login!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php } ?>
    </body>
</html>