<?php ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Forgot Password</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../assets/build/css/app-638f2af77c.css">
        <link rel="preload" href="../assets/fonts/proximanova/regular/proximanova-regular-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/regular/proximanova-regular-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/bold/proximanova-bold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/bold/proximanova-bold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/light/proximanova-light-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/light/proximanova-light-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/semibold/proximanova-semibold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff2" as="font" type="font/woff2" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/thin/Proxima-Nova-Thin.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="../assets/fonts/proximanova/thin/Proxima-Nova-Thin.ttf" as="font" type="font/ttf" crossorigin />
        <link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body class="bg-gradient-primary">
        <section>
            <div class="container">

                <!-- Outer Row -->
                <div class="row justify-content-center">

                    <div class="col-xl-10 col-lg-12 col-md-9">

                        <div class="card o-hidden border-0 shadow-lg my-5">
                            <div class="card-body p-0">
                                <!-- Nested Row within Card Body -->
                                <div class="row">
                                    <div class="col-lg-6 d-none d-lg-block bg-password-image"></div>
                                    <div class="col-lg-6">
                                        <div class="p-5">
                                            <div class="text-center">
                                                <h1 class="h4 text-gray-900 mb-2">Forgot Your Password?</h1>
                                                <p class="mb-4">We get it, stuff happens. Just enter your email address below and we'll send you a link to reset your password!</p>
                                            </div>
                                            <form class="user">
                                                <div class="form-group">
                                                    <input type="email" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                                                </div>
                                                <a href="login.php" class="btn btn-primary btn-user btn-block">
                                                    Reset Password
                                                </a>
                                            </form>
                                            <hr>
                                            <div class="text-center">
                                                <a class="small" href="registration.php">Create an Account!</a>
                                            </div>
                                            <div class="text-center">
                                                <a class="small" href="login.php">Already have an account? Login!</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </section> 
        <?php ?>
        <script src="../assets/js/jquery-3.4.1.js" type="text/javascript"></script>
        <script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
    </body>
</html>