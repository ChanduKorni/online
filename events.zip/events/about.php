<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Online Event Management</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="assets/build/css/app-638f2af77c.css">
        <link rel="preload" href="assets/fonts/proximanova/regular/proximanova-regular-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/regular/proximanova-regular-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/bold/proximanova-bold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/bold/proximanova-bold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/light/proximanova-light-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/light/proximanova-light-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.ttf" as="font" type="font/ttf" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/semibold/proximanova-semibold-webfont.woff2" as="font" type="font/woff2" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/thin/Proxima-Nova-Thin.woff" as="font" type="font/woff" crossorigin />
        <link rel="preload" href="assets/fonts/proximanova/thin/Proxima-Nova-Thin.ttf" as="font" type="font/ttf" crossorigin />
        <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        //include auth.php file on all secure pages
        include("auth.php");
        ?>
        <nav class="navbar navbar-default fixed-top navbar-expand-lg navbar-dark bg-dark pad20 scrolled" data-spy="affix" data-offset-top="400">
            <div class="container">
                <a class="navbar-brand logo-fntsz1pt5" href="index.php">QIS EVENTS</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="about.php">About us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Events
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="wedding.php">Wedding Events</a>
                                <a class="dropdown-item" href="party.php">Party Events</a>
                                <a class="dropdown-item" href="corporate.php">Corporate Events</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="customers/login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact us</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--/ End of navbar /-->
        <section class="section-event-main-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="abt-title mrgntop100">
                            <h2 class="text-center text-white">About us</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of about title /-->
        <section class="section-main-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="who-title mrgnbtm35">
                            <h2 class="text-center">Our History</h2>
                            <h6 class="text-center">Creating Successful Events through People-Centered, Ethnic Traditional Designs</h6>
                        </div>
                        <div class="row mrgnbtm35">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="who text-center">
                                    <img src="assets/images/1.png" class="img-fluid mrgnbtm15" alt="img">
                                    <h3>Who We Are?</h3>
                                    <h6 class="text-justify lineht25">QIS Events is an full service event management company which believes in creating exceptional & flawless event experiences. We believe in creating moments which shall become memories to be cherished forever</h6>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="who text-center">
                                    <img src="assets/images/2.png" class="img-fluid mrgnbtm15" alt="img">
                                    <h3>What We Can Do?</h3>
                                    <h6 class="text-justify lineht25">At QIS Events we continuosly strive to be innovative, creative & our we believe in designing or creating events tailormade for you. We take care of each and every detail, right from the Venue layout and Color scheme to the Food and Beverages catering, every element is crafted carefull.</h6>
                                </div>
                            </div>
                        </div>
                        <div class="row mrgnbtm35">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="who text-center">
                                    <img src="assets/images/3.png" class="img-fluid mrgnbtm15" alt="img">
                                    <h3>Friendly Team</h3>
                                    <h6 class="text-justify lineht25">What makes us truly different is our philosophy of “Unleashing Energy” At QIS events we are  blessed with a vibrant team of skilled Event professionals with loads of experience and Talents. Finally, it is our incessant endeavour to deliver Quality beyond the expectations of our Clients.</h6>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="who text-center">
                                    <img src="assets/images/4.png" class="img-fluid mrgnbtm15" alt="img">
                                    <h3>Unforgettable Time</h3>
                                    <h6 class="text-justify lineht25">We believe in creating moments which shall become memories to be cherished forever. QIS events offers unique ideas and themes that make any event truly original and engaging. We always make sure every event that we create is elegant and unique which meets your event objectives at the same time an unforgettable time which shall be cherished for life long.</h6>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="who text-center">
                                    <img src="assets/images/5.png" class="img-fluid mrgnbtm15" alt="img">
                                    <h3>Unique Scenarios</h3>
                                    <h6 class="text-justify lineht25">QIS Events specialises in creative an impeccable platform, which made us achieve the optimal impact and left an everlasting impression on our latest decorations, handling events, especially high quality food and ever lasting taste.</h6>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="who text-center">
                                    <img src="assets/images/6.png" class="img-fluid mrgnbtm15" alt="img">
                                    <h3>Perfect Venues</h3>
                                    <h6 class="text-justify lineht25">Every event needs the right venue to showcase the spectacle. let it be your wedding, product launch or anniversary bash, our event services team offers the most luxurious and bespoke venues that can serve as the perfect backdrop for the celebrations, within your budget.</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of who we are /-->
        <section class="contact-foo-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <div class="contact">
                                    <h3 class="text-white">Contact</h3>
                                    <p class="footer_color_white text-white">
                                        QIS COLLEGE OF ENGINEERING & TECHNOLOGY<br> vengamukkapalem, Ongole - 523272<br> Andhra Pradesh, India<br>
                                        <span class="footer_color_white">E:</span> <a class="footer_color_white text-white" href="mailto:principal@qiscet.edu.in">principal@qiscet.edu.in</a><br>
                                        <span class="footer_color_white">T:</span> <a class="footer_color_white text-white" href="tel:+91 8592 - 281023">+91 8592 - 281023</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4"></div>
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <aside class="f_widget f_subs_widget">
                                    <div class="f_title" style="padding-bottom: 25px !important;">
                                        <h3 class="text-white">Follow us</h3>
                                    </div>
                                    <div class="input-group">
                                        <a target="_blank" href="#"><i class="fab fa-google-plus-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-linkedin" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-facebook-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                        <a target="_blank" href="#"><i class="fab fa-twitter-square" aria-hidden="true" style="font-size:24px;color: #FFF;letter-spacing: 0.5rem;"></i></a>
                                    </div>
                                </aside>
                            </div>
                        </div>
                        <p class="text-white text-center mrgntop-50">Copyright © 2019 QIS Group of Institutions - All right reserved.</p>
                    </div>
                </div>
            </div>
        </section>
        <!--/ End of contact us /-->
        <script src="assets/js/jquery-3.4.1.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $(window).scroll(function () {
                    $("nav").toggleClass("scrolled", $(this).scrollTop() > 50);
                });
            });
        </script>
    </body>
</html>
